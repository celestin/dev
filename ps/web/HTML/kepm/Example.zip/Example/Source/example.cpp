// Example.cpp
// Test and sample program for CodeVis VidCapture
// Written by Michael Ellison
//-------------------------------------------------------------------------
//                      CodeVis's Free License
//                         www.codevis.com
//
// Copyright (c) 2003 by Michael Ellison (mike@codevis.com)
// All rights reserved.
//
// You may use this software in source and/or binary form, with or without
// modification, for commercial or non-commercial purposes, provided that 
// you comply with the following conditions:
//
// * Redistributions of source code must retain the above copyright notice,
//   this list of conditions and the following disclaimer. 
//
// * Redistributions of modified source must be clearly marked as modified,
//   and due notice must be placed in the modified source indicating the
//   type of modification(s) and the name(s) of the person(s) performing
//   said modification(s).
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
// LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//---------------------------------------------------------------------------
// Modifications:
//
//---------------------------------------------------------------------------

// if STOP_BEFORE_EXIT is defined,
// we'll wait for a key hit before exiting.
// #define STOP_BEFORE_EXIT

// if LOOP_TEST is defined, we'll loop until a key is hit
// #define LOOP_TEST


#if (defined(STOP_BEFORE_EXIT) || defined(LOOP_TEST))
   #include <conio.h>
#endif

#ifdef STOP_BEFORE_EXIT
   // Clear any existing keystrokes, then wait for a final one on exit.
   #define EXIT_MACRO printf("Press any key to exit...\n"); \
                      while (kbhit()) {getch();} \
                      getch();
#else
   #define EXIT_MACRO
#endif




#include <stdio.h>
 #include "VidCapture.h"

// You only need to include this if you plan on using CodeVis utility
// or tracing functions
#include "CVUtil.h"

bool TestIt();

bool enumCallback(   const char*             devname, 
                     void*                   userParam);

bool capCallback (   CVRES                   status,
                     CVImage*                image,
                     void*                   userParam);

void SlowNegateImage(CVImage* image);

// Global test device name
char gDeviceName[256];

// Global frame count
int gFrameNum = 0;   // Offset

// Global device number
int gDevNum = 0; 

//--------------------------------------------------------------------
void main()
{
   printf("-------------------------------------------------------\n");
   printf("CodeVis VidCapture Test Program                        \n");
   printf("%s",kVIDCAPTURE_STRING);
   printf("-------------------------------------------------------\n");

#ifdef LOOP_TEST
   printf("Looping until you press a key.\n");
   // Loop until key hit
   while (!kbhit())
   {
      // reset globals for another pass...
      memset(gDeviceName,0,sizeof(gDeviceName));
      gFrameNum = 0;
      gDevNum = 0;
#endif // LOOP_TEST
      
      static int testRunNumber = 1;

      if (false == TestIt())
      {
         printf("************* Test run %d failed!\n", testRunNumber);
         EXIT_MACRO
         return;
      }
      else
      {
         printf("Test run %d succeeded.\n", testRunNumber++);
      }

#ifdef LOOP_TEST
   } // end while (!kbhit)
#endif

   EXIT_MACRO
}



bool TestIt()
{
   // Acquire a video capture object from CVPlatform.
   // You can also just instantiate a CVVidCaptureDSWin32 object
   // directly, but this way the code is platform-neutral.
   CVVidCapture* vidCap = CVPlatform::GetPlatform()->AcquireVideoCapture();

   // First initialize the video capture interface
   // by calling Init().
   if (CVSUCCESS(vidCap->Init()))
   {
      printf("Initialized video capture object.\n");
   }
   else
   {
      printf("Error initializing video capture object.\n");
      
      // Release the video capture object.
      // You could also just delete it right now, but using this
      // method allows us to switch to a singleton if we need
      // for subclasses of CVVidCapture, lets us reference count
      // if desired, etc.
      CVPlatform::GetPlatform()->Release(vidCap);                  
      return false;
   }

   // Enumerate devices.
   // The enumCallback is called for each available
   // video capture device.  Our current enumeration
   // callback just saves the first one. In practice,
   // you'd usually want to add these to a list and
   // let the user select one if the last selected
   // one was not available.
   //
   // Note that the video capture interface must
   // first be initialized before enumerating devices.
   memset(gDeviceName,0,256);
   
   int numDevices = 0;
   if (CVFAILED(vidCap->GetNumDevices(numDevices)))
   {
      printf("Failed enumerating devices.\n");
      vidCap->Uninit();
      CVPlatform::GetPlatform()->Release(vidCap);      
      return false;
   }

   CVVidCapture::VIDCAP_DEVICE devInfo;

   int curDevIndex = 0;
   for (curDevIndex = 0; curDevIndex < numDevices; curDevIndex++)
   {
      if (CVSUCCESS(vidCap->GetDeviceInfo(curDevIndex,devInfo)))
      {
         printf("Device %d: %s\n",curDevIndex,devInfo.DeviceString);
      }
   }

   // Now connect to the selected device.
   if (CVSUCCESS(vidCap->Connect(1)))
   {
      int devNameLen = 0;
      vidCap->GetDeviceName(0,devNameLen);
      devNameLen++;
      char *devName = new char[devNameLen];
      vidCap->GetDeviceName(devName,devNameLen);
      
      printf("Connection succeeded to %s.\n",devName);
      delete [] devName;
   }
   else
   {
      printf("Connection failed.\n");
      vidCap->Uninit();
      CVPlatform::GetPlatform()->Release(vidCap);      
      return false;
   }

   // Get the number of supported modes.
   // Mode changes can be done any time we're not
   // grabbing.
   //
   CVVidCapture::VIDCAP_MODE modeInfo;
   int numModes = 0;
   vidCap->GetNumSupportedModes(numModes);

   // Dump each mode 
   for (int curmode = 0; curmode < numModes; curmode++)
   {
      if (CVSUCCESS(vidCap->GetModeInfo(curmode, modeInfo)))
      {
         printf(  "Available mode: %d, %dx%d @ %d frames/sec (%s)\n",
                  curmode, 
                  modeInfo.XRes, 
                  modeInfo.YRes,
                  modeInfo.EstFrameRate,
                  vidCap->GetFormatModeName(modeInfo.InputFormat));
      } 
   }

   
   if (CVFAILED(vidCap->SetMode(0)))    // Set to first available mode
   //if (CVFAILED(vidCap->SetMode(2)))      // Set to the third mode
   {
      printf("Error setting video mode.\n");
   }

   // Get the mode info of our selected mode and print it.
   if (CVFAILED(vidCap->GetCurrentMode(modeInfo)))
   {
      printf("Error activating mode!\n");
   }
   else
   {
      printf("Activated mode: %dx%d\n",modeInfo.XRes, modeInfo.YRes);   
   }

   // Set contrast to 50% if supported. Only some video capture devices
   // will support the properties.
   long minval,maxval;
   if (CVSUCCESS(vidCap->GetPropertyInfo( CVVidCapture::CAMERAPROP_CONTRAST,
                                          0,
                                          0,
                                          &minval, 
                                          &maxval)))
   {
      printf("Contrast supported\n", minval, maxval);    
      vidCap->SetProperty( CVVidCapture::CAMERAPROP_CONTRAST,
                           (minval+maxval)/2);
   }
   else
   {
      printf("Contrast unsupported.\n");
   }

   // Now set the brightness if available.
   if (CVSUCCESS(vidCap->GetPropertyInfo( CVVidCapture::CAMERAPROP_BRIGHT,
                                          0,
                                          0,
                                          &minval, 
                                          &maxval)))
   {
      printf("Brightness supported\n", minval, maxval);     
      vidCap->SetProperty( CVVidCapture::CAMERAPROP_BRIGHT,
                           (minval+maxval)/2);
   }
   else
   {
      printf("Brightness unsupported.\n");
   }


   // Grab a grey image
   CVImage* grabImage = 0;

   printf("Grabbing grey image...\n");
   if (CVSUCCESS(vidCap->Grab(CVImage::CVIMAGE_GREY, grabImage)))
   {            
      if (CVFAILED(CVImage::Save("GreyGrab",grabImage)))
      {
         printf("Failed saving grey image.");
      }
      // We're responsible for freeing the image,
      // so do so now.
      CVImage::ReleaseImage(grabImage);
   }
   else
   {
      printf("Grey Grab failed.\n");
   }

   // Grab a color image
   printf("Grabbing color image...\n");
   if (CVSUCCESS(vidCap->Grab(CVImage::CVIMAGE_RGB24, grabImage)))
   {            
      if (CVFAILED(CVImage::Save("ColorGrab",grabImage)))
      {
         printf("Failed saving color image.");
      }
      // We're responsible for freeing the image,
      // so do so now.
      CVImage::ReleaseImage(grabImage);
   }
   else
   {
      printf("Color Grab failed.\n");
   }

   // Start a continuous image capture.
   // As each image comes in, capCallback will be called with
   // a pointer to the converted image.

   // First, do 2 seconds of grey
   bool started = false;

   printf("Starting grey image capture...\n");

   started = CVSUCCESS(vidCap->StartImageCap(CVImage::CVIMAGE_GREY, capCallback,0));
   if (!started)
   {
      printf("Error starting capture....\n");
   }      
   else
   {
      // Let it capture in image mode for 2 seconds
      Sleep(2000);
   
      // Stop the capture
      printf("Stopping image capture...\n");
      vidCap->Stop();
   }

   // Now do 2 seconds of color...
   printf("Starting color image capture...\n");
   started = CVSUCCESS(vidCap->StartImageCap(CVImage::CVIMAGE_RGB24, capCallback,0));
   if (!started)
   {
      printf("Error starting capture....\n");
   }      
   else
   {
      // Let it capture in image mode for 2 seconds
      Sleep(2000);
   
      // Stop the capture
      printf("Stopping image capture...\n");
      vidCap->Stop();
   }

   // Always disconnect from the device when you're done
   printf("Disconnecting...\n");
   vidCap->Disconnect();   

   // And uninitialize before deleting it
   printf("Uninitializing video capture...\n");
   vidCap->Uninit();

   // Release video capture object.
   CVPlatform::GetPlatform()->Release(vidCap);      
   return true;
}

//-------------------------------------------------------------------------
// Callback for enumeration of capture devices.
//
// We're just saving the first one that comes by 
// into gDeviceName[] and using it.
bool enumCallback(const char* devname, void* userParam)
{      
   
  // if (gDevNum < 1)     // use the first device
   if (gDevNum <= 1)    // use the second device
   {
      strcpy(gDeviceName,devname);
   }
   
   gDevNum++;

   printf("Device: %s\n",devname);
   return true;
}


//-------------------------------------------------------------------------
// capCallback is the main image capture callback.
//
// We play with the image a bit inside to test out
// CVImage's functions.
//
bool capCallback( CVRES             status,
                  CVImage*          imagePtr,
                  void*             userParam)
{
   static int xOffset  = 0;
   static int yOffset  = 0;

   // Only try to work with the image pointer if the
   // status is successful!
   if (CVSUCCESS(status))
   {      
      char framePath[_MAX_PATH];
      sprintf(framePath,"cap_frame_%d",gFrameNum);

      CVAssert(imagePtr != 0, "This shouldn't happen. Bad image pointer.");

      printf("Captured frame %d.\n", gFrameNum);

      // Create a sub image
      CVImage* subImg = 0;
      int subWidth = imagePtr->Width() / 4;
      int subHeight = imagePtr->Height() / 5;
      
      if (CVFAILED(CVImage::CreateSub( imagePtr,
                                       subImg, 
                                       xOffset, 
                                       yOffset, 
                                       subWidth, 
                                       subHeight)))
      {
         printf("Failed creating sub image!\n");
      }
      else
      {
         // Negate the sub image
         SlowNegateImage(subImg);

         // Create a sub image of the sub image 5 pixels in from each side
         CVImage *subSubImg = 0;
         if (CVFAILED(CVImage::CreateSub( subImg,
                                          subSubImg,
                                          5,
                                          5,
                                          subWidth-10,
                                          subHeight-10)))
         {
            printf("Failed creating sub image of sub image\n");
            // Release first sub image
            CVImage::ReleaseImage(subImg);
         }
         else
         {
            // Release first sub image 
            // (this shouldn't delete subImg - subSubImg holds a reference)
            CVImage::ReleaseImage(subImg);
            
            // Negate subSubImg - this should restore the center of subImg
            // area to its original colors, just leaving a 5 pixel border of
            // negative around it.
            SlowNegateImage(subSubImg);

            // Release subSubImg
            CVImage::ReleaseImage(subSubImg);
         }
                        
         // Setup offsets for next sub image
         xOffset += subWidth; 
         yOffset += subHeight;

         if (imagePtr->Width() - xOffset < subWidth)
         {
            xOffset = 0;
         }
         if (imagePtr->Height() - yOffset < subHeight)
         {
            yOffset = 0;
         }

      }

      // Save the base image
      if (CVFAILED(CVImage::Save(framePath, imagePtr)))
      {
         printf("Failed saving image!\n");
      }
            
      gFrameNum++;
   }
   else
   {
      // From here, you'd usually want to signal your main thread 
      // that the capture has been terminated. This is the only notice
      // you'll receive - no more callbacks after this.
      //
      // In this example, since we're just sleeping briefly, there's
      // no need to signal the main thread.
      // 
      printf("Capture failure in callback! Did you disconnect camera?\n");
   }

   // Halt on frame 25 just to test halting from within a callback.
   if (gFrameNum == 25)
   {
      printf("Halting prematurely to test callback exit codes.\n");
      printf("Returning false here should abort the capture.\n");
      // Of course, you'll still need to call CVVidCapture::Stop()
      // from the main thread to clean up.
      return false;
   }   
   return true;
}

//-------------------------------------------------------------------------
// SlowNegateImage() is a slow routine to negate an image.
//
// Works on any image type where the pixel values are 0-255,
// but it recalculates each pixel location in addition to 
// having 2 subroutine calls per pixel - lots of overhead. 
// Good for testing CVImage::GetPixel() and CVImage::SetPixel() though.
//
void SlowNegateImage(CVImage* image)
{
   // Verify that our getpixel/setpixel stuff works even
   // on sub images by creating a negative within the
   // sub image, then saving the parent (which should
   // now have a negative rectangle in it)
   for (int x = 0; x < image->Width(); x++)
   {
      for (int y=0; y < image->Height(); y++)
      {
         float r,g,b;
         if (CVFAILED(image->GetPixel(x,y,r,g,b)))
         {
            printf("GetPixel Error!\n");
         }
         else
         {
            // Assumes images are 0-255. If not, this will
            // generate funky results.
            r = 255.0f - r;
            g = 255.0f - g;
            b = 255.0f - b;
         
            if (CVFAILED(image->SetPixel(x,y,r,g,b)))
            {
               printf("SetPixel Error!\n");
            }
         }
      }
   }
}
