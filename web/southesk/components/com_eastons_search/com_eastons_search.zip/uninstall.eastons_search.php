<?php
/* * * * * * * * * * * * * * * * * * * * * * * *
 * Southesk.com
 * Copyright (c) 2006 Frontburner
 * Author Craig McKay <craig@frontburner.co.uk>
 *
 * Easton's Bible Dictionary Search Component Installation
 *
 * $Id: uninstall.hymn_search.php 176 2006-07-02 17:21:02Z craig $
 *
 * Who  When         Why
 * CAM  02-Jul-2006  File added to source control.
 * * * * * * * * * * * * * * * * * * * * * * * */

function com_uninstall() {
 echo "Thank you for using this component. Please contact me at craig@southesk.com with any questions";
}
?>
